package tn.essat;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AppExApplicationTests {

	@Test
	void contextLoads() {
	}

}
